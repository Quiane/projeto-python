# Este programa imprime uma mensagem de saudação

# Imprime a mensagem na tela
print("Olá, mundo")