# Calculadora de Média Escolar

# Notas do Aluno
nota_1 = float(input("Digite a primeira nota: "))
nota_2 = float(input("Digite a segunda nota: "))
nota_3 = float(input("Digite a terceira nota: "))

# Calculo da Media
media = (nota_1 + nota_2 + nota_3) / 3

# Exibição dos Resultados
print(f"Notas do Aluno")
print(f"Nota 1: {nota_1}")
print(f"Nota 2: {nota_2}")
print(f"Nota 3: {nota_3}")
print(f"Media Final: {media:.2f}")